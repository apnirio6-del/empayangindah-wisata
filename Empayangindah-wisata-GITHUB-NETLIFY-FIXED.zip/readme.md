# Empayangindah.wisata v8.1 — Supabase Online

Versi ini memperbaiki alur verifikasi email Supabase:
- Saat membuat akun admin, email verifikasi diarahkan kembali ke alamat website yang sedang dibuka, bukan hard-coded localhost.
- Supabase Publishable key berada di `assets/config.js`.
- Data admin, perjalanan, booking, dan pengaturan perusahaan tersimpan online di Supabase.

## Setelah upload ke Netlify
1. Di Supabase > Authentication > URL Configuration, isi Site URL dengan alamat Netlify Anda.
2. Tambahkan `https://ALAMAT-NETLIFY-ANDA.netlify.app/**` ke Redirect URLs.
3. Jika Confirm email aktif, buat akun admin lalu buka email verifikasi TERBARU.
4. Setelah verifikasi, kembali ke website dan login.

Jangan masukkan Secret/Service Role key ke file website.


## Login admin v8.2
- Login menggunakan alamat EMAIL Supabase, bukan Display Name/username.
- Jika user Auth sudah terverifikasi tetapi belum masuk `admin_users`, login pertama akan otomatis mengklaim akun tersebut sebagai admin pertama.
- Jika muncul `email rate limit exceeded`, jangan menekan Buat Akun Admin berulang kali. Gunakan akun yang sudah ada dan login dengan email/password yang sama.
- Setelah email dikonfirmasi, login langsung dari `admin.html` menggunakan email yang terdaftar.


## Reset password fixed
Supabase Dashboard → Authentication → URL Configuration → Redirect URLs: tambahkan URL website Anda dengan path `/reset-password.html`. Contoh: `https://domain-anda.netlify.app/reset-password.html`.

Alur reset: Lupa Password → email → link reset → **Buat Password Baru** → simpan → kembali ke Login Admin.
