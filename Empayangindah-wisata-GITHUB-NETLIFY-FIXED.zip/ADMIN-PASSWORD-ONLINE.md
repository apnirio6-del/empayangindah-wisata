# Empayangindah.wisata — Admin Password Online

## Login
Halaman admin hanya meminta **password**. Email admin tidak ditampilkan pada form.

Identitas akun yang dipakai di Supabase saat ini adalah:
`apniproject61@gmail.com`

Password diverifikasi oleh Supabase Auth sehingga akun yang sama dapat dipakai dari HP, laptop, atau perangkat lain.

## Reset password
Pemulihan password dilakukan dari **Supabase Dashboard → Authentication → Users** pada akun admin.
Jangan memasukkan Service Role/Secret key ke website.

## Catatan keamanan
Password tidak disimpan di website atau database aplikasi. Jangan mengubah `ADMIN_EMAIL` kecuali akun Supabase admin juga diubah.
