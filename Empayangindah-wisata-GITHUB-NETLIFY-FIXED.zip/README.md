# Empayangindah.wisata — Admin Online

Admin menggunakan Supabase Auth sehingga akun yang sama dapat login dari HP, tablet, laptop, dan perangkat lain menggunakan email + password yang sama.

Pemulihan password dilakukan melalui Supabase Authentication, bukan melalui halaman website.

Supabase Project: https://bmxwwdpycdmdloufzxlb.supabase.co

Jangan masukkan Secret/Service Role key ke frontend.
